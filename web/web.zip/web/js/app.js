particlesJS.load('particles-js', 'js/particles.json', function() {
  console.log('particles.js loaded - callback');
});
